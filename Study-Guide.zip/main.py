with open('reference.txt') as txt:
  lines = txt.readlines()

with open('name.txt') as nme:
  names = nme.readlines()

study = {} 
for x in range(len(lines)):
  study[x] = lines[x]

for y in range((len(names))):
  study[names[y].strip()] = study[y]



def newLine(txt):
  splt = txt.split("\\")
  for text in splt:
    print(text)
  # This function will put the text on separate lines.


ask = []
for x in range(len(names)):
  ask.append("On a scale of 1-5 how well do you know " +  names[x].strip() + " : ")

for y in range(len(ask)):
  user = int(input(ask[y]))
  if user <= 3: 
    print("\nYou seem like you need to study")
    newLine(study[names[y].strip()])
  elif user > 3:
    print("You're good to go on", names[y].strip() + "! Good job!")
  else:
    print("You must've entered an incorrect value...\nMoving on...")
  

print("\n\nYou've completed your studying! Good job!")